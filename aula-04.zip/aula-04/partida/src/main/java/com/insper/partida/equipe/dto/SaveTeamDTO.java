package com.insper.partida.equipe.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SaveTeamDTO {
    private String identifier;
    private String name;
    private String stadium;
}
