package com.insper.partida.game.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EditGameDTO {
    private Integer scoreHome;
    private Integer scoreAway;
    private Integer attendance;
}
