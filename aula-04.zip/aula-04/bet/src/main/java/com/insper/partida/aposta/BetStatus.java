package com.insper.partida.aposta;

public enum BetStatus {
    WON, LOST
}
